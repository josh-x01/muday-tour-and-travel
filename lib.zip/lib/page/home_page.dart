import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:project/widgets/location_card.dart';
import 'package:project/widgets/nearby_places.dart';
import 'package:project/widgets/recommended_places.dart';
import 'package:project/widgets/tourist_places.dart';
import 'package:flutter_calendar_carousel/flutter_calendar_carousel.dart'
    show CalendarCarousel;

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late PageController _pageController;
  int _currentIndex = 0;
  String _ethiopianCalendar = '';
  String _currencyExchangeRate = '';
  TextEditingController _amountController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  void _onPageChanged(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  void _onBottomNavTapped(int index) {
    _pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  Future<void> getEthiopianCalendar() async {
    try {
      var response = await http
          .get(Uri.parse('https://api.example.com/ethiopian_calendar'));
      if (response.statusCode == 200) {
        setState(() {
          _ethiopianCalendar = response.body;
        });
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  Future<void> getCurrencyExchangeRate() async {
    try {
      var response = await http
          .get(Uri.parse('https://api.example.com/currency_exchange'));
      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        setState(() {
          _currencyExchangeRate = "100";
        });
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        title: Center(
          child: Text("Tour Application"),
        ),
      ),
      body: PageView(
        controller: _pageController,
        onPageChanged: _onPageChanged,
        children: [
          // Page 1: Home Page
          ListView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.all(14),
            children: [
              // LOCATION CARD
              const LocationCard(),
              const SizedBox(height: 15),
              const TouristPlaces(),
              // CATEGORIES
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Recommendation",
                    style: Theme.of(context).textTheme.headline6,
                  ),
                ],
              ),
              const SizedBox(height: 10),
              const RecommendedPlaces(),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Places",
                    style: Theme.of(context).textTheme.headline6,
                  ),
                ],
              ),
              const SizedBox(height: 10),
              const NearbyPlaces(),
            ],
          ),

          // Page 2: Calendar Page
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Ethiopian Calendar',
                style: Theme.of(context).textTheme.headline6,
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: getEthiopianCalendar,
                child: Text('Get Calendar'),
              ),
              const SizedBox(height: 10),
              Expanded(
                child: CalendarCarousel(
                  selectedDateTime: DateTime.now(),
                  showHeader: false,
                  todayButtonColor: Colors.transparent,
                  todayBorderColor: Colors.transparent,
                  markedDatesMap: null, // Add marked dates if needed
                  onDayPressed: (DateTime date, List<dynamic> events) {
                    // Handle day press event if needed
                  },
                ),
              ),
            ],
          ),

          // Page 3: Currency Page
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Currency Exchange',
                style: Theme.of(context).textTheme.headline6,
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: getCurrencyExchangeRate,
                child: Text('Get Exchange Rate'),
              ),
              const SizedBox(height: 10),
              Text('Enter amount:'),
              TextField(
                controller: _amountController,
                keyboardType: TextInputType.number,
              ),
              ElevatedButton(
                onPressed: () {
                  double amount =
                      double.tryParse(_amountController.text) ?? 0.0;
                  double result = 12.21;
                  (_currencyExchangeRate);
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text('Conversion Result'),
                      content: Text('$amount ETB = $result GC'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text('OK'),
                        ),
                      ],
                    ),
                  );
                },
                child: Text('Convert'),
              ),
            ],
          ),

          // Page 4: Profile Page
          Container(color: Color.fromARGB(255, 50, 12, 103)),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        showSelectedLabels: false,
        showUnselectedLabels: false,
        currentIndex: _currentIndex,
        onTap: _onBottomNavTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Ionicons.home_outline),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Ionicons.calendar),
            label: "Calendar",
          ),
          BottomNavigationBarItem(
            icon: Icon(Ionicons.cash_outline),
            label: "Currency",
          ),
          BottomNavigationBarItem(
            icon: Icon(Ionicons.person_outline),
            label: "Profile",
          ),
        ],
      ),
    );
  }
}
