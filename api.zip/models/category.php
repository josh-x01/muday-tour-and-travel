<?php
include_once('../config.php');

function getCategories($id)
{
  $table_name = 'category';
  $query = 'SELECT * from ' . $table_name;
  $result = execQuery($query);
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $category = [
        'id' => $row['id'],
        'name' => $row['name'],
      ];
    }
    $response = [
      "status" => 200,
      "data" => $category
    ];
    return $response;
  } else {
    return [];
  }
}
